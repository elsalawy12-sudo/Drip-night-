import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

export default function ProfilePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-primary font-space-grotesk">
              Drip Night
            </Link>
            <div className="hidden md:flex items-center gap-6">
              <Link href="/shop" className="text-foreground hover:text-primary transition-colors">
                المتجر
              </Link>
              <Link href="/lookbook" className="text-foreground hover:text-primary transition-colors">
                معرض الأزياء
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                من نحن
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                تواصل معنا
              </Link>
              <Link href="/gallery" className="text-foreground hover:text-primary transition-colors">
                المعرض
              </Link>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/profile" className="text-primary font-semibold">
                الملف الشخصي
              </Link>
              <Button variant="outline" size="sm">
                تسجيل الخروج
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Profile Content */}
      <div className="pt-24 pb-12 px-4">
        <div className="container mx-auto max-w-4xl">
          {/* Profile Header */}
          <div className="text-center mb-12">
            <div className="w-24 h-24 bg-primary rounded-full mx-auto mb-4 flex items-center justify-center">
              <span className="text-3xl text-primary-foreground">👤</span>
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2 font-space-grotesk">أحمد محمد</h1>
            <p className="text-muted-foreground">عضو منذ يناير 2025</p>
            <Badge className="mt-2 bg-accent">عضو مميز</Badge>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Profile Settings */}
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="font-space-grotesk">المعلومات الشخصية</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-card-foreground mb-2">الاسم الأول</label>
                      <Input defaultValue="أحمد" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-card-foreground mb-2">الاسم الأخير</label>
                      <Input defaultValue="محمد" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">البريد الإلكتروني</label>
                    <Input type="email" defaultValue="ahmed@example.com" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">رقم الهاتف</label>
                    <Input type="tel" defaultValue="+966 50 123 4567" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">العنوان</label>
                    <Textarea defaultValue="الرياض، المملكة العربية السعودية" rows={3} />
                  </div>
                  <Button className="w-full md:w-auto">حفظ التغييرات</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="font-space-grotesk">تغيير كلمة المرور</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">كلمة المرور الحالية</label>
                    <Input type="password" placeholder="أدخل كلمة المرور الحالية" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">كلمة المرور الجديدة</label>
                    <Input type="password" placeholder="أدخل كلمة المرور الجديدة" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">
                      تأكيد كلمة المرور الجديدة
                    </label>
                    <Input type="password" placeholder="أعد إدخال كلمة المرور الجديدة" />
                  </div>
                  <Button variant="outline" className="w-full md:w-auto bg-transparent">
                    تحديث كلمة المرور
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="font-space-grotesk">إحصائيات الحساب</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">إجمالي الطلبات</span>
                    <span className="font-bold text-primary">12</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">المبلغ المنفق</span>
                    <span className="font-bold text-primary">3,450 ريال</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">النقاط المكتسبة</span>
                    <span className="font-bold text-primary">345 نقطة</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="font-space-grotesk">الطلبات الأخيرة</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                    <div>
                      <p className="font-semibold text-sm">طلب #1234</p>
                      <p className="text-xs text-muted-foreground">15 يناير 2025</p>
                    </div>
                    <Badge variant="outline" className="bg-green-100 text-green-800">
                      مكتمل
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                    <div>
                      <p className="font-semibold text-sm">طلب #1235</p>
                      <p className="text-xs text-muted-foreground">18 يناير 2025</p>
                    </div>
                    <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
                      قيد التجهيز
                    </Badge>
                  </div>
                  <Link href="/orders">
                    <Button variant="outline" size="sm" className="w-full bg-transparent">
                      عرض جميع الطلبات
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="font-space-grotesk">الإعدادات السريعة</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                    🔔 إعدادات الإشعارات
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                    🎁 برنامج الولاء
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                    📍 عناوين الشحن
                  </Button>
                  <Button variant="outline" size="sm" className="w-full justify-start bg-transparent">
                    💳 طرق الدفع
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold text-card-foreground mb-4 font-space-grotesk">Drip Night</h3>
              <p className="text-muted-foreground">متجرك المفضل للملابس الشبابية العصرية</p>
            </div>
            <div>
              <h4 className="font-semibold text-card-foreground mb-4">روابط سريعة</h4>
              <div className="space-y-2">
                <Link href="/shop" className="block text-muted-foreground hover:text-primary transition-colors">
                  المتجر
                </Link>
                <Link href="/about" className="block text-muted-foreground hover:text-primary transition-colors">
                  من نحن
                </Link>
                <Link href="/contact" className="block text-muted-foreground hover:text-primary transition-colors">
                  تواصل معنا
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-card-foreground mb-4">خدمة العملاء</h4>
              <div className="space-y-2">
                <Link href="/shipping" className="block text-muted-foreground hover:text-primary transition-colors">
                  الشحن والتوصيل
                </Link>
                <Link href="/returns" className="block text-muted-foreground hover:text-primary transition-colors">
                  الإرجاع والاستبدال
                </Link>
                <Link href="/faq" className="block text-muted-foreground hover:text-primary transition-colors">
                  الأسئلة الشائعة
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-card-foreground mb-4">تابعنا</h4>
              <div className="flex gap-4">
                <Button variant="outline" size="sm">
                  Instagram
                </Button>
                <Button variant="outline" size="sm">
                  TikTok
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center">
            <p className="text-muted-foreground">© 2025 Drip Night. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
