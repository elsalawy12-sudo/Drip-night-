import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"

const galleryItems = [
  {
    id: 1,
    title: "هودي رالف إمباير الرمادي",
    category: "هوديز",
    image: "/images/hoodie-gray.png",
  },
  {
    id: 2,
    title: "هودي النجوم الأسود",
    category: "هوديز",
    image: "/images/hoodie-black-star.png",
  },
  {
    id: 3,
    title: "هودي سوبريم ستايل",
    category: "هوديز",
    image: "/images/hoodie-supreme.png",
  },
  {
    id: 4,
    title: "هودي الجماجم البني",
    category: "هوديز",
    image: "/images/hoodie-brown-skull.png",
  },
  {
    id: 5,
    title: "تصميم حصري 1",
    category: "تصاميم",
    image: "/exclusive-streetwear-design.png",
  },
  {
    id: 6,
    title: "تصميم حصري 2",
    category: "تصاميم",
    image: "/urban-fashion-design.png",
  },
]

export default function GalleryPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-primary font-space-grotesk">
              Drip Night
            </Link>
            <div className="hidden md:flex items-center gap-6">
              <Link href="/shop" className="text-foreground hover:text-primary transition-colors">
                المتجر
              </Link>
              <Link href="/lookbook" className="text-foreground hover:text-primary transition-colors">
                معرض الأزياء
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                من نحن
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                تواصل معنا
              </Link>
              <Link href="/gallery" className="text-primary font-semibold">
                المعرض
              </Link>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/login">
                <Button variant="outline" size="sm">
                  تسجيل الدخول
                </Button>
              </Link>
              <Link href="/register">
                <Button size="sm">إنشاء حساب</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-12 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 font-space-grotesk">
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">المعرض</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            مجموعة من أفضل تصاميمنا وإبداعاتنا الفنية
          </p>
        </div>
      </section>

      {/* Filter Buttons */}
      <section className="pb-8 px-4">
        <div className="container mx-auto">
          <div className="flex flex-wrap gap-4 justify-center">
            <Button variant="default" size="sm">
              جميع الأعمال
            </Button>
            <Button variant="outline" size="sm">
              هوديز
            </Button>
            <Button variant="outline" size="sm">
              تصاميم
            </Button>
            <Button variant="outline" size="sm">
              إكسسوارات
            </Button>
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="pb-20 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {galleryItems.map((item, index) => (
              <Card
                key={item.id}
                className={`group cursor-pointer hover:shadow-2xl transition-all duration-500 overflow-hidden ${index % 3 === 1 ? "md:translate-y-8" : ""}`}
              >
                <CardContent className="p-0">
                  <div className="relative aspect-square overflow-hidden">
                    <Image
                      src={item.image || "/placeholder.svg"}
                      alt={item.title}
                      fill
                      className="object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-500">
                      <span className="inline-block px-3 py-1 bg-primary rounded-full text-sm mb-3">
                        {item.category}
                      </span>
                      <h3 className="text-xl font-bold font-space-grotesk">{item.title}</h3>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Load More */}
          <div className="text-center mt-16">
            <Button size="lg" variant="outline" className="px-12 bg-transparent">
              تحميل المزيد
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-card">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold text-card-foreground mb-4 font-space-grotesk">أعجبتك التصاميم؟</h2>
          <p className="text-muted-foreground mb-8">تسوق الآن من مجموعتنا الحصرية</p>
          <Link href="/shop">
            <Button size="lg" className="px-8">
              تسوق الآن
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-background border-t border-border py-12 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold text-foreground mb-4 font-space-grotesk">Drip Night</h3>
              <p className="text-muted-foreground">متجرك المفضل للملابس الشبابية العصرية</p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">روابط سريعة</h4>
              <div className="space-y-2">
                <Link href="/shop" className="block text-muted-foreground hover:text-primary transition-colors">
                  المتجر
                </Link>
                <Link href="/about" className="block text-muted-foreground hover:text-primary transition-colors">
                  من نحن
                </Link>
                <Link href="/contact" className="block text-muted-foreground hover:text-primary transition-colors">
                  تواصل معنا
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">خدمة العملاء</h4>
              <div className="space-y-2">
                <Link href="/shipping" className="block text-muted-foreground hover:text-primary transition-colors">
                  الشحن والتوصيل
                </Link>
                <Link href="/returns" className="block text-muted-foreground hover:text-primary transition-colors">
                  الإرجاع والاستبدال
                </Link>
                <Link href="/faq" className="block text-muted-foreground hover:text-primary transition-colors">
                  الأسئلة الشائعة
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">تابعنا</h4>
              <div className="flex gap-4">
                <Button variant="outline" size="sm">
                  Instagram
                </Button>
                <Button variant="outline" size="sm">
                  TikTok
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center">
            <p className="text-muted-foreground">© 2025 Drip Night. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
