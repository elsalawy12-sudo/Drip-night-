import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import Link from "next/link"

export default function ForgotPasswordPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background/90 to-primary/5"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.05)_0%,transparent_50%)]"></div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="text-3xl font-bold text-primary font-space-grotesk">
            Drip Night
          </Link>
          <p className="text-muted-foreground mt-2">استعادة كلمة المرور</p>
        </div>

        {/* Forgot Password Form */}
        <Card className="shadow-2xl border-border/50 backdrop-blur-sm bg-card/80">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-card-foreground font-space-grotesk">
              نسيت كلمة المرور؟
            </CardTitle>
            <p className="text-muted-foreground">أدخل بريدك الإلكتروني وسنرسل لك رابط لإعادة تعيين كلمة المرور</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-card-foreground mb-2">البريد الإلكتروني</label>
                <Input
                  type="email"
                  placeholder="أدخل بريدك الإلكتروني"
                  className="bg-input/50 border-border focus:border-primary transition-colors"
                />
              </div>

              <Button size="lg" className="w-full bg-primary hover:bg-primary/90 transition-colors">
                إرسال رابط الاستعادة
              </Button>
            </form>

            {/* Back to Login */}
            <div className="text-center pt-4">
              <p className="text-muted-foreground">
                تذكرت كلمة المرور؟{" "}
                <Link href="/login" className="text-primary hover:text-accent font-semibold transition-colors">
                  تسجيل الدخول
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Back to Home */}
        <div className="text-center mt-6">
          <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
            ← العودة إلى الصفحة الرئيسية
          </Link>
        </div>
      </div>
    </div>
  )
}
