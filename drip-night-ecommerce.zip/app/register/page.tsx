import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import Link from "next/link"

export default function RegisterPage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4 py-8">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background/90 to-primary/5"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.05)_0%,transparent_50%)]"></div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="text-3xl font-bold text-primary font-space-grotesk">
            Drip Night
          </Link>
          <p className="text-muted-foreground mt-2">انضم إلى عائلة Drip Night</p>
        </div>

        {/* Register Form */}
        <Card className="shadow-2xl border-border/50 backdrop-blur-sm bg-card/80">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-card-foreground font-space-grotesk">
              إنشاء حساب جديد
            </CardTitle>
            <p className="text-muted-foreground">أدخل بياناتك لإنشاء حسابك</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <form className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-card-foreground mb-2">الاسم الأول</label>
                  <Input
                    type="text"
                    placeholder="الاسم الأول"
                    className="bg-input/50 border-border focus:border-primary transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-card-foreground mb-2">الاسم الأخير</label>
                  <Input
                    type="text"
                    placeholder="الاسم الأخير"
                    className="bg-input/50 border-border focus:border-primary transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-card-foreground mb-2">البريد الإلكتروني</label>
                <Input
                  type="email"
                  placeholder="أدخل بريدك الإلكتروني"
                  className="bg-input/50 border-border focus:border-primary transition-colors"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-card-foreground mb-2">رقم الهاتف</label>
                <Input
                  type="tel"
                  placeholder="أدخل رقم هاتفك"
                  className="bg-input/50 border-border focus:border-primary transition-colors"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-card-foreground mb-2">كلمة المرور</label>
                <Input
                  type="password"
                  placeholder="أدخل كلمة المرور"
                  className="bg-input/50 border-border focus:border-primary transition-colors"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-card-foreground mb-2">تأكيد كلمة المرور</label>
                <Input
                  type="password"
                  placeholder="أعد إدخال كلمة المرور"
                  className="bg-input/50 border-border focus:border-primary transition-colors"
                />
              </div>

              <div className="space-y-3">
                <div className="flex items-start space-x-2 space-x-reverse">
                  <Checkbox id="terms" className="mt-1" />
                  <label htmlFor="terms" className="text-sm text-card-foreground cursor-pointer leading-relaxed">
                    أوافق على{" "}
                    <Link href="/terms" className="text-primary hover:text-accent transition-colors">
                      الشروط والأحكام
                    </Link>{" "}
                    و{" "}
                    <Link href="/privacy" className="text-primary hover:text-accent transition-colors">
                      سياسة الخصوصية
                    </Link>
                  </label>
                </div>

                <div className="flex items-start space-x-2 space-x-reverse">
                  <Checkbox id="newsletter" className="mt-1" />
                  <label htmlFor="newsletter" className="text-sm text-card-foreground cursor-pointer">
                    أريد الحصول على العروض والأخبار عبر البريد الإلكتروني
                  </label>
                </div>
              </div>

              <Button size="lg" className="w-full bg-primary hover:bg-primary/90 transition-colors">
                إنشاء الحساب
              </Button>
            </form>

            {/* Divider */}
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-border" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-2 text-muted-foreground">أو</span>
              </div>
            </div>

            {/* Social Register */}
            <div className="space-y-3">
              <Button variant="outline" size="lg" className="w-full bg-transparent border-border hover:bg-accent/10">
                <span className="mr-2">📱</span>
                التسجيل بـ Google
              </Button>
              <Button variant="outline" size="lg" className="w-full bg-transparent border-border hover:bg-accent/10">
                <span className="mr-2">📘</span>
                التسجيل بـ Facebook
              </Button>
            </div>

            {/* Login Link */}
            <div className="text-center pt-4">
              <p className="text-muted-foreground">
                لديك حساب بالفعل؟{" "}
                <Link href="/login" className="text-primary hover:text-accent font-semibold transition-colors">
                  تسجيل الدخول
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Back to Home */}
        <div className="text-center mt-6">
          <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
            ← العودة إلى الصفحة الرئيسية
          </Link>
        </div>
      </div>
    </div>
  )
}
