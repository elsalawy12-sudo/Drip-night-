"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import Image from "next/image"

const products = [
  {
    id: 1,
    name: "هودي رالف إمباير",
    price: 299,
    originalPrice: 349,
    image: "/images/hoodie-gray.png",
    category: "هوديز",
    isNew: true,
    description: "هودي رمادي كلاسيكي بتصميم عصري وخامة فاخرة",
    slug: "hoodie-gray",
  },
  {
    id: 2,
    name: "هودي النجوم الأسود",
    price: 349,
    image: "/images/hoodie-black-star.png",
    category: "هوديز",
    isFeatured: true,
    description: "هودي أسود مميز بتصميم النجوم والرموز الفريدة",
    slug: "hoodie-black-star",
  },
  {
    id: 3,
    name: "هودي سوبريم ستايل",
    price: 399,
    image: "/images/hoodie-supreme.png",
    category: "هوديز",
    isPopular: true,
    description: "هودي بتصميم سوبريم الشهير وخط عريض مميز",
    slug: "hoodie-supreme",
  },
  {
    id: 4,
    name: "هودي الجماجم البني",
    price: 379,
    originalPrice: 429,
    image: "/images/hoodie-brown-skull.png",
    category: "هوديز",
    isLimited: true,
    description: "هودي بني بتصميم الجماجم الفني وسحاب أمامي",
    slug: "hoodie-brown-skull",
  },
]

export default function ShopPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-primary font-space-grotesk">
              Drip Night
            </Link>
            <div className="hidden md:flex items-center gap-6">
              <Link href="/shop" className="text-primary font-semibold">
                المتجر
              </Link>
              <Link href="/lookbook" className="text-foreground hover:text-primary transition-colors">
                معرض الأزياء
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                من نحن
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                تواصل معنا
              </Link>
              <Link href="/gallery" className="text-foreground hover:text-primary transition-colors">
                المعرض
              </Link>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/login">
                <Button variant="outline" size="sm">
                  تسجيل الدخول
                </Button>
              </Link>
              <Link href="/register">
                <Button size="sm">إنشاء حساب</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-12 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 font-space-grotesk">
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">المتجر</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              اكتشف تشكيلتنا الحصرية من الهوديز والملابس الشبابية العصرية
            </p>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="pb-8 px-4">
        <div className="container mx-auto">
          <div className="flex flex-wrap gap-4 justify-center">
            <Button variant="default" size="sm">
              جميع المنتجات
            </Button>
            <Button variant="outline" size="sm">
              هوديز
            </Button>
            <Button variant="outline" size="sm">
              تي شيرت
            </Button>
            <Button variant="outline" size="sm">
              إكسسوارات
            </Button>
            <Button variant="outline" size="sm">
              محدود
            </Button>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="pb-20 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {products.map((product) => (
              <Link key={product.id} href={`/product/${product.slug}`}>
                <Card className="group cursor-pointer hover:shadow-2xl transition-all duration-500 hover:scale-105 bg-card border-border overflow-hidden">
                  <CardContent className="p-0">
                    {/* Product Image */}
                    <div className="relative aspect-square overflow-hidden bg-muted">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        fill
                        className="object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                      {/* Badges */}
                      <div className="absolute top-4 right-4 flex flex-col gap-2">
                        {product.isNew && <Badge className="bg-primary text-primary-foreground">جديد</Badge>}
                        {product.isFeatured && <Badge className="bg-accent text-accent-foreground">مميز</Badge>}
                        {product.isPopular && <Badge className="bg-chart-2 text-white">الأكثر مبيعاً</Badge>}
                        {product.isLimited && (
                          <Badge className="bg-destructive text-destructive-foreground">محدود</Badge>
                        )}
                        {product.originalPrice && (
                          <Badge variant="secondary" className="bg-chart-3 text-white">
                            خصم
                          </Badge>
                        )}
                      </div>

                      {/* Hover Overlay */}
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                        <Button
                          size="lg"
                          className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300"
                        >
                          عرض التفاصيل
                        </Button>
                      </div>
                    </div>

                    {/* Product Info */}
                    <div className="p-6">
                      <div className="mb-2">
                        <Badge variant="outline" className="text-xs">
                          {product.category}
                        </Badge>
                      </div>
                      <h3 className="font-bold text-lg text-card-foreground mb-2 group-hover:text-primary transition-colors">
                        {product.name}
                      </h3>
                      <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{product.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl font-bold text-primary">{product.price} ريال</span>
                          {product.originalPrice && (
                            <span className="text-sm text-muted-foreground line-through">
                              {product.originalPrice} ريال
                            </span>
                          )}
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-transparent"
                          onClick={(e) => e.preventDefault()}
                        >
                          أضف للسلة
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          {/* Load More */}
          <div className="text-center mt-16">
            <Button size="lg" variant="outline" className="px-12 bg-transparent">
              تحميل المزيد من المنتجات
            </Button>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 px-4 bg-card">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold text-card-foreground mb-4 font-space-grotesk">اشترك في النشرة الإخبارية</h2>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            كن أول من يعرف عن المنتجات الجديدة والعروض الحصرية
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <input
              type="email"
              placeholder="أدخل بريدك الإلكتروني"
              className="flex-1 px-4 py-3 rounded-lg bg-input border border-border text-card-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <Button size="lg">اشتراك</Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-background border-t border-border py-12 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold text-foreground mb-4 font-space-grotesk">Drip Night</h3>
              <p className="text-muted-foreground">متجرك المفضل للملابس الشبابية العصرية</p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">روابط سريعة</h4>
              <div className="space-y-2">
                <Link href="/shop" className="block text-muted-foreground hover:text-primary transition-colors">
                  المتجر
                </Link>
                <Link href="/about" className="block text-muted-foreground hover:text-primary transition-colors">
                  من نحن
                </Link>
                <Link href="/contact" className="block text-muted-foreground hover:text-primary transition-colors">
                  تواصل معنا
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">خدمة العملاء</h4>
              <div className="space-y-2">
                <Link href="/shipping" className="block text-muted-foreground hover:text-primary transition-colors">
                  الشحن والتوصيل
                </Link>
                <Link href="/returns" className="block text-muted-foreground hover:text-primary transition-colors">
                  الإرجاع والاستبدال
                </Link>
                <Link href="/faq" className="block text-muted-foreground hover:text-primary transition-colors">
                  الأسئلة الشائعة
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">تابعنا</h4>
              <div className="flex gap-4">
                <Button variant="outline" size="sm">
                  Instagram
                </Button>
                <Button variant="outline" size="sm">
                  TikTok
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center">
            <p className="text-muted-foreground">© 2025 Drip Night. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
