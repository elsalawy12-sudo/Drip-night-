"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import ThemeToggle from "../components/theme-toggle"

export default function HomePage() {
  const [isDarkMode, setIsDarkMode] = useState(true)
  const [showScrollNav, setShowScrollNav] = useState(false)

  useEffect(() => {
    const savedTheme = localStorage.getItem("theme")
    if (savedTheme) {
      const isDark = savedTheme === "dark"
      setIsDarkMode(isDark)
      document.documentElement.classList.toggle("dark", isDark)
    }
  }, [])

  useEffect(() => {
    const handleScroll = () => {
      const currentScroll = window.pageYOffset
      if (currentScroll > 150) {
        setShowScrollNav(true)
      } else if (currentScroll < 100) {
        setShowScrollNav(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleTheme = () => {
    const newTheme = !isDarkMode
    setIsDarkMode(newTheme)
    document.documentElement.classList.toggle("dark", newTheme)
    localStorage.setItem("theme", newTheme ? "dark" : "light")
  }

  return (
    <div className={isDarkMode ? "dark" : ""}>
      <div
        style={{
          margin: 0,
          background: isDarkMode ? "#000" : "#fff",
          color: isDarkMode ? "#fff" : "#000",
          fontFamily: "Arial, sans-serif",
          overflowX: "hidden",
          minHeight: "100vh",
        }}
      >
        <ThemeToggle isDarkMode={isDarkMode} onToggle={toggleTheme} />

        {/* Scroll Navbar */}
        <div
          className="scroll-navbar"
          style={{
            position: "fixed",
            top: showScrollNav ? "0" : "-80px",
            left: 0,
            width: "100%",
            background: isDarkMode ? "rgba(0,0,0,0.85)" : "rgba(255,255,255,0.85)",
            backdropFilter: "blur(6px)",
            padding: "10px 20px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            transition: "top 0.4s ease",
            zIndex: 9999,
          }}
        >
          <div
            style={{
              fontFamily: "Metal Mania, cursive",
              fontSize: "28px",
              color: "#ff4d4d",
              animation: "spin 8s linear infinite",
              cursor: "grab",
              whiteSpace: "nowrap",
            }}
          >
            drip night
          </div>
          <nav style={{ display: "flex", gap: "20px", overflowX: "auto", whiteSpace: "nowrap" }}>
            <Link
              href="#home"
              style={{
                position: "relative",
                padding: "6px 14px",
                border: `1px solid ${isDarkMode ? "#fff" : "#000"}`,
                borderRadius: "6px",
                color: isDarkMode ? "#fff" : "#000",
                textDecoration: "none",
                fontSize: "16px",
                transition: "0.3s",
              }}
            >
              HOME
            </Link>
            <Link
              href="/shop"
              style={{
                position: "relative",
                padding: "6px 14px",
                border: `1px solid ${isDarkMode ? "#fff" : "#000"}`,
                borderRadius: "6px",
                color: isDarkMode ? "#fff" : "#000",
                textDecoration: "none",
                fontSize: "16px",
                transition: "0.3s",
              }}
            >
              SHOP
            </Link>
            <Link
              href="/lookbook"
              style={{
                position: "relative",
                padding: "6px 14px",
                border: `1px solid ${isDarkMode ? "#fff" : "#000"}`,
                borderRadius: "6px",
                color: isDarkMode ? "#fff" : "#000",
                textDecoration: "none",
                fontSize: "16px",
                transition: "0.3s",
              }}
            >
              LOOKBOOK
            </Link>
            <Link
              href="/contact"
              style={{
                position: "relative",
                padding: "6px 14px",
                border: `1px solid ${isDarkMode ? "#fff" : "#000"}`,
                borderRadius: "6px",
                color: isDarkMode ? "#fff" : "#000",
                textDecoration: "none",
                fontSize: "16px",
                transition: "0.3s",
              }}
            >
              CONTACT
            </Link>
            <Link
              href="/about"
              style={{
                position: "relative",
                padding: "6px 14px",
                border: `1px solid ${isDarkMode ? "#fff" : "#000"}`,
                borderRadius: "6px",
                color: isDarkMode ? "#fff" : "#000",
                textDecoration: "none",
                fontSize: "16px",
                transition: "0.3s",
              }}
            >
              ABOUT
            </Link>
            <Link
              href="/gallery"
              style={{
                position: "relative",
                padding: "6px 14px",
                border: `1px solid ${isDarkMode ? "#fff" : "#000"}`,
                borderRadius: "6px",
                color: isDarkMode ? "#fff" : "#000",
                textDecoration: "none",
                fontSize: "16px",
                transition: "0.3s",
              }}
            >
              GALLERY
            </Link>
            <Link
              href="/login"
              style={{
                position: "relative",
                padding: "6px 14px",
                border: `1px solid ${isDarkMode ? "#fff" : "#000"}`,
                borderRadius: "6px",
                color: isDarkMode ? "#fff" : "#000",
                textDecoration: "none",
                fontSize: "16px",
                transition: "0.3s",
              }}
            >
              LOGIN
            </Link>
          </nav>
        </div>

        {/* Hero Section */}
        <div
          className="hero"
          style={{
            position: "relative",
            height: "100vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            perspective: "1200px",
            overflow: "hidden",
            background: isDarkMode
              ? "radial-gradient(circle at center, rgba(255,0,85,0.2), rgba(0,0,0,0.8))"
              : "radial-gradient(circle at center, rgba(255,0,85,0.1), rgba(255,255,255,0.9))",
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              background: isDarkMode
                ? "radial-gradient(circle at center, rgba(255,0,85,0.2), rgba(0,0,0,0.8))"
                : "radial-gradient(circle at center, rgba(255,0,85,0.1), rgba(255,255,255,0.9))",
              mixBlendMode: "screen",
              zIndex: 1,
              pointerEvents: "none",
            }}
          />
          <div style={{ position: "relative", zIndex: 2, textAlign: "center" }}>
            <div
              className="logo"
              style={{
                fontFamily: "Metal Mania, cursive",
                fontSize: "clamp(60px, 15vw, 180px)",
                color: "#ff4d4d",
                transformStyle: "preserve-3d",
                animation: "spin 8s linear infinite",
                textShadow: "0 0 8px rgba(255,77,77,.8), 0 0 20px rgba(155,89,255,.6)",
                cursor: "grab",
                userSelect: "none",
              }}
            >
              drip night
            </div>
            <div
              className="menu"
              style={{
                marginTop: "24px",
                display: "flex",
                flexDirection: "column",
                gap: "12px",
                alignItems: "center",
              }}
            >
              <Link
                href="/shop"
                style={{
                  position: "relative",
                  padding: "10px 24px",
                  border: `1px solid ${isDarkMode ? "#fff" : "#000"}`,
                  color: isDarkMode ? "#fff" : "#000",
                  textDecoration: "none",
                  fontSize: "18px",
                  borderRadius: "8px",
                  overflow: "hidden",
                  transition: "transform 0.2s, color 0.3s, box-shadow 0.3s",
                  opacity: 0,
                  transform: "translateY(20px)",
                  animation: "fadeUp 0.6s ease forwards 0.3s",
                }}
              >
                SHOP
              </Link>
              <Link
                href="/lookbook"
                style={{
                  position: "relative",
                  padding: "10px 24px",
                  border: `1px solid ${isDarkMode ? "#fff" : "#000"}`,
                  color: isDarkMode ? "#fff" : "#000",
                  textDecoration: "none",
                  fontSize: "18px",
                  borderRadius: "8px",
                  overflow: "hidden",
                  transition: "transform 0.2s, color 0.3s, box-shadow 0.3s",
                  opacity: 0,
                  transform: "translateY(20px)",
                  animation: "fadeUp 0.6s ease forwards 0.5s",
                }}
              >
                LOOKBOOK
              </Link>
              <Link
                href="/contact"
                style={{
                  position: "relative",
                  padding: "10px 24px",
                  border: `1px solid ${isDarkMode ? "#fff" : "#000"}`,
                  color: isDarkMode ? "#fff" : "#000",
                  textDecoration: "none",
                  fontSize: "18px",
                  borderRadius: "8px",
                  overflow: "hidden",
                  transition: "transform 0.2s, color 0.3s, box-shadow 0.3s",
                  opacity: 0,
                  transform: "translateY(20px)",
                  animation: "fadeUp 0.6s ease forwards 0.7s",
                }}
              >
                CONTACT
              </Link>
            </div>
            <div
              className="socials"
              style={{
                marginTop: "20px",
                display: "flex",
                gap: "14px",
                justifyContent: "center",
              }}
            >
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">
                <div
                  style={{
                    width: "28px",
                    height: "28px",
                    background: "#1877f2",
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "white",
                    fontSize: "14px",
                    transition: "transform 0.2s ease",
                  }}
                >
                  f
                </div>
              </a>
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                <div
                  style={{
                    width: "28px",
                    height: "28px",
                    background: "#1da1f2",
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "white",
                    fontSize: "14px",
                    transition: "transform 0.2s ease",
                  }}
                >
                  t
                </div>
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
                <div
                  style={{
                    width: "28px",
                    height: "28px",
                    background: "linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%)",
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "white",
                    fontSize: "14px",
                    transition: "transform 0.2s ease",
                  }}
                >
                  i
                </div>
              </a>
              <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer">
                <div
                  style={{
                    width: "28px",
                    height: "28px",
                    background: "#000",
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "white",
                    fontSize: "14px",
                    transition: "transform 0.2s ease",
                  }}
                >
                  ♪
                </div>
              </a>
            </div>
          </div>
        </div>

        {/* Shop Section */}
        <section id="shop" style={{ padding: "80px 20px", textAlign: "center" }}>
          <h2 style={{ fontSize: "36px", marginBottom: "16px", color: isDarkMode ? "#fff" : "#000" }}>SHOP</h2>
          <p
            style={{
              maxWidth: "600px",
              margin: "auto",
              color: isDarkMode ? "#ccc" : "#666",
              fontSize: "17px",
              lineHeight: "1.5",
            }}
          >
            تسوق أحدث تشكيلة من Drip Night — خامات فاخره، تصميمات محدودة، ستايل لاُمثيل له.
          </p>
          <div
            className="products"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
              gap: "20px",
              marginTop: "40px",
            }}
          >
            <Link href="/product/hoodie-gray">
              <div
                className="product"
                style={{
                  background: isDarkMode ? "#111" : "#f5f5f5",
                  borderRadius: "12px",
                  overflow: "hidden",
                  transform: "scale(0.9)",
                  opacity: 1,
                  transition: "0.3s",
                  cursor: "pointer",
                }}
              >
                <img src="/images/hoodie-gray.png" alt="هودي رمادي" style={{ width: "100%", display: "block" }} />
                <h3 style={{ padding: "10px", color: isDarkMode ? "#fff" : "#000" }}>هودي رالف إمباير - رمادي</h3>
              </div>
            </Link>
            <Link href="/product/hoodie-black-star">
              <div
                className="product"
                style={{
                  background: isDarkMode ? "#111" : "#f5f5f5",
                  borderRadius: "12px",
                  overflow: "hidden",
                  transform: "scale(0.9)",
                  opacity: 1,
                  transition: "0.3s",
                  cursor: "pointer",
                }}
              >
                <img
                  src="/images/hoodie-black-star.png"
                  alt="هودي أسود بالنجوم"
                  style={{ width: "100%", display: "block" }}
                />
                <h3 style={{ padding: "10px", color: isDarkMode ? "#fff" : "#000" }}>هودي النجوم الأسود</h3>
              </div>
            </Link>
            <Link href="/product/hoodie-supreme">
              <div
                className="product"
                style={{
                  background: isDarkMode ? "#111" : "#f5f5f5",
                  borderRadius: "12px",
                  overflow: "hidden",
                  transform: "scale(0.9)",
                  opacity: 1,
                  transition: "0.3s",
                  cursor: "pointer",
                }}
              >
                <img src="/images/hoodie-supreme.png" alt="هودي سوبريم" style={{ width: "100%", display: "block" }} />
                <h3 style={{ padding: "10px", color: isDarkMode ? "#fff" : "#000" }}>هودي سوبريم ستايل</h3>
              </div>
            </Link>
            <Link href="/product/hoodie-brown-skull">
              <div
                className="product"
                style={{
                  background: isDarkMode ? "#111" : "#f5f5f5",
                  borderRadius: "12px",
                  overflow: "hidden",
                  transform: "scale(0.9)",
                  opacity: 1,
                  transition: "0.3s",
                  cursor: "pointer",
                }}
              >
                <img
                  src="/images/hoodie-brown-skull.png"
                  alt="هودي بني بالجماجم"
                  style={{ width: "100%", display: "block" }}
                />
                <h3 style={{ padding: "10px", color: isDarkMode ? "#fff" : "#000" }}>هودي الجماجم البني</h3>
              </div>
            </Link>
          </div>
        </section>

        {/* Lookbook Section */}
        <section id="lookbook" style={{ padding: "80px 20px", textAlign: "center" }}>
          <h2 style={{ fontSize: "36px", marginBottom: "16px", color: isDarkMode ? "#fff" : "#000" }}>LOOKBOOK</h2>
          <p
            style={{
              maxWidth: "600px",
              margin: "auto",
              color: isDarkMode ? "#ccc" : "#666",
              fontSize: "17px",
              lineHeight: "1.5",
            }}
          >
            استلهم من جلسات التصوير الحصرية لبراندنا.
          </p>
        </section>

        {/* Contact Section */}
        <section id="contact" style={{ padding: "80px 20px", textAlign: "center" }}>
          <h2 style={{ fontSize: "36px", marginBottom: "16px", color: isDarkMode ? "#fff" : "#000" }}>CONTACT</h2>
          <p
            style={{
              maxWidth: "600px",
              margin: "auto",
              color: isDarkMode ? "#ccc" : "#666",
              fontSize: "17px",
              lineHeight: "1.5",
            }}
          >
            لو عندك أي استفسار أو طلب خاص، تواصل معانا مباشرة.
          </p>
        </section>

        {/* Footer */}
        <footer
          style={{
            background: isDarkMode ? "#111" : "#f5f5f5",
            padding: "40px 20px 20px",
            textAlign: "center",
            color: isDarkMode ? "#777" : "#666",
            fontSize: "14px",
            borderTop: `1px solid ${isDarkMode ? "#333" : "#ddd"}`,
          }}
        >
          <div style={{ marginBottom: "20px" }}>© 2025 Drip Night — جميع الحقوق محفوظة</div>
          {/* Developer Information Section */}
          <div
            style={{
              padding: "15px 0",
              borderTop: `1px solid ${isDarkMode ? "#333" : "#ddd"}`,
              fontSize: "13px",
              color: isDarkMode ? "#999" : "#888",
            }}
          >
            <div style={{ marginBottom: "8px" }}>
              تطوير: <span style={{ color: "#ff4d4d", fontWeight: "bold" }}>Elsalawy</span>
            </div>
            <div>
              للتواصل واتس اب:
              <a
                href="https://wa.me/201094991757"
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  color: "#25D366",
                  textDecoration: "none",
                  fontWeight: "bold",
                  marginLeft: "5px",
                }}
              >
                01094991757
              </a>
            </div>
          </div>
        </footer>

        <style jsx>{`
          @import url('https://fonts.googleapis.com/css2?family=Metal+Mania&display=swap');
          
          @keyframes spin {
            from { transform: rotateY(0deg); }
            to { transform: rotateY(360deg); }
          }
          
          @keyframes fadeUp {
            to { opacity: 1; transform: translateY(0); }
          }
          
          .product:hover {
            transform: scale(1) !important;
            box-shadow: 0 0 20px rgba(255,77,77,0.5);
          }
          
          .scroll-navbar nav a:hover {
            color: #ff4d4d;
            transform: translateY(4px) scale(1.05);
          }
          
          .menu a:hover {
            color: #ff4d4d;
            transform: translateY(8px) scale(1.05);
            box-shadow: 0 0 15px rgba(255,77,77,0.5);
          }
          
          .socials div:hover {
            transform: scale(1.3);
          }
        `}</style>
      </div>
    </div>
  )
}
