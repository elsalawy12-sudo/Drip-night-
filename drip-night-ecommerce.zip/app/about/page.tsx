import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-primary font-space-grotesk">
              Drip Night
            </Link>
            <div className="hidden md:flex items-center gap-6">
              <Link href="/shop" className="text-foreground hover:text-primary transition-colors">
                المتجر
              </Link>
              <Link href="/lookbook" className="text-foreground hover:text-primary transition-colors">
                معرض الأزياء
              </Link>
              <Link href="/about" className="text-primary font-semibold">
                من نحن
              </Link>
              <Link href="/contact" className="text-foreground hover:text-primary transition-colors">
                تواصل معنا
              </Link>
              <Link href="/gallery" className="text-foreground hover:text-primary transition-colors">
                المعرض
              </Link>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/login">
                <Button variant="outline" size="sm">
                  تسجيل الدخول
                </Button>
              </Link>
              <Link href="/register">
                <Button size="sm">إنشاء حساب</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-12 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 font-space-grotesk">
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">من نحن</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            قصة براند Drip Night ورحلتنا في عالم الأزياء الشبابية
          </p>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-foreground mb-6 font-space-grotesk">قصتنا</h2>
              <p className="text-muted-foreground text-lg leading-relaxed mb-6">
                بدأت Drip Night كحلم بسيط - إنشاء براند يعبر عن روح الشباب العربي ويجمع بين الأصالة والعصرية. منذ
                انطلاقتنا، كان هدفنا واضحاً: تقديم ملابس عالية الجودة بتصاميم فريدة تناسب الذوق العربي.
              </p>
              <p className="text-muted-foreground text-lg leading-relaxed mb-8">
                نحن نؤمن بأن الأزياء ليست مجرد ملابس، بل وسيلة للتعبير عن الشخصية والهوية. لذلك نحرص على اختيار أفضل
                الخامات وأحدث التصاميم لنقدم لكم تجربة تسوق مميزة.
              </p>
              <Link href="/shop">
                <Button size="lg">اكتشف مجموعتنا</Button>
              </Link>
            </div>
            <div className="relative">
              <div className="aspect-square bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl font-bold text-primary mb-4 font-space-grotesk">2025</div>
                  <p className="text-muted-foreground">سنة التأسيس</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 px-4 bg-card">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-card-foreground mb-4 font-space-grotesk">قيمنا</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">المبادئ التي نؤمن بها ونعمل من خلالها</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center hover:shadow-xl transition-all duration-300">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-2xl text-primary-foreground">🎨</span>
                </div>
                <h3 className="text-xl font-bold text-card-foreground mb-4">الإبداع</h3>
                <p className="text-muted-foreground">نسعى دائماً لتقديم تصاميم مبتكرة وفريدة تواكب أحدث صيحات الموضة</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-xl transition-all duration-300">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-2xl text-accent-foreground">⭐</span>
                </div>
                <h3 className="text-xl font-bold text-card-foreground mb-4">الجودة</h3>
                <p className="text-muted-foreground">نختار أفضل الخامات ونهتم بأدق التفاصيل لضمان رضاكم التام</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-xl transition-all duration-300">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-chart-2 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-2xl text-white">🤝</span>
                </div>
                <h3 className="text-xl font-bold text-card-foreground mb-4">الثقة</h3>
                <p className="text-muted-foreground">نبني علاقات طويلة الأمد مع عملائنا من خلال الشفافية والمصداقية</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold text-foreground mb-12 font-space-grotesk">فريق العمل</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-24 h-24 bg-primary rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-2xl text-primary-foreground">👨‍💼</span>
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">أحمد محمد</h3>
                <p className="text-primary mb-2">المؤسس والمدير التنفيذي</p>
                <p className="text-muted-foreground text-sm">خبرة 10 سنوات في مجال الأزياء والتجارة الإلكترونية</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-24 h-24 bg-accent rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-2xl text-accent-foreground">👩‍🎨</span>
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">فاطمة علي</h3>
                <p className="text-primary mb-2">مديرة التصميم</p>
                <p className="text-muted-foreground text-sm">متخصصة في تصميم الأزياء الشبابية والعصرية</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-24 h-24 bg-chart-2 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-2xl text-white">👨‍💻</span>
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">محمد سالم</h3>
                <p className="text-primary mb-2">مدير التسويق الرقمي</p>
                <p className="text-muted-foreground text-sm">خبير في التسويق الإلكتروني ووسائل التواصل الاجتماعي</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-background border-t border-border py-12 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold text-foreground mb-4 font-space-grotesk">Drip Night</h3>
              <p className="text-muted-foreground">متجرك المفضل للملابس الشبابية العصرية</p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">روابط سريعة</h4>
              <div className="space-y-2">
                <Link href="/shop" className="block text-muted-foreground hover:text-primary transition-colors">
                  المتجر
                </Link>
                <Link href="/about" className="block text-muted-foreground hover:text-primary transition-colors">
                  من نحن
                </Link>
                <Link href="/contact" className="block text-muted-foreground hover:text-primary transition-colors">
                  تواصل معنا
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">خدمة العملاء</h4>
              <div className="space-y-2">
                <Link href="/shipping" className="block text-muted-foreground hover:text-primary transition-colors">
                  الشحن والتوصيل
                </Link>
                <Link href="/returns" className="block text-muted-foreground hover:text-primary transition-colors">
                  الإرجاع والاستبدال
                </Link>
                <Link href="/faq" className="block text-muted-foreground hover:text-primary transition-colors">
                  الأسئلة الشائعة
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">تابعنا</h4>
              <div className="flex gap-4">
                <Button variant="outline" size="sm">
                  Instagram
                </Button>
                <Button variant="outline" size="sm">
                  TikTok
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center">
            <p className="text-muted-foreground">© 2025 Drip Night. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
