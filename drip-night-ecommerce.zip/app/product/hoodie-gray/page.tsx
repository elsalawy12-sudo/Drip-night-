"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import ThemeToggle from "../../../components/theme-toggle"

export default function HoodieGrayPage() {
  const [isDarkMode, setIsDarkMode] = useState(true)
  const [quantity, setQuantity] = useState(1)
  const [selectedSize, setSelectedSize] = useState("M")

  useEffect(() => {
    const savedTheme = localStorage.getItem("theme")
    if (savedTheme) {
      const isDark = savedTheme === "dark"
      setIsDarkMode(isDark)
      document.documentElement.classList.toggle("dark", isDark)
    }
  }, [])

  const toggleTheme = () => {
    const newTheme = !isDarkMode
    setIsDarkMode(newTheme)
    document.documentElement.classList.toggle("dark", newTheme)
    localStorage.setItem("theme", newTheme ? "dark" : "light")
  }

  return (
    <div className={isDarkMode ? "dark" : ""}>
      <div
        style={{
          margin: 0,
          background: isDarkMode ? "#000" : "#fff",
          color: isDarkMode ? "#fff" : "#000",
          fontFamily: "Arial, sans-serif",
          minHeight: "100vh",
        }}
      >
        <ThemeToggle isDarkMode={isDarkMode} onToggle={toggleTheme} />

        {/* Header */}
        <header style={{ padding: "20px", borderBottom: `1px solid ${isDarkMode ? "#333" : "#ddd"}` }}>
          <Link
            href="/"
            style={{ color: "#ff4d4d", textDecoration: "none", fontSize: "24px", fontFamily: "Metal Mania, cursive" }}
          >
            ← العودة للرئيسية
          </Link>
        </header>

        {/* Product Details */}
        <div style={{ padding: "40px 20px", maxWidth: "1200px", margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "40px", alignItems: "start" }}>
            {/* Product Image */}
            <div style={{ textAlign: "center" }}>
              <img
                src="/images/hoodie-gray.png"
                alt="هودي رالف إمباير - رمادي"
                style={{
                  width: "100%",
                  maxWidth: "500px",
                  borderRadius: "12px",
                  boxShadow: isDarkMode ? "0 10px 30px rgba(255,77,77,0.3)" : "0 10px 30px rgba(0,0,0,0.1)",
                }}
              />
            </div>

            {/* Product Info */}
            <div>
              <h1 style={{ fontSize: "36px", marginBottom: "16px", color: "#ff4d4d" }}>هودي رالف إمباير - رمادي</h1>
              <p style={{ fontSize: "18px", color: isDarkMode ? "#ccc" : "#666", marginBottom: "20px" }}>
                هودي فاخر من تشكيلة رالف إمباير بتصميم عصري وخامة قطنية عالية الجودة. مثالي للإطلالات اليومية والمناسبات
                الكاجوال.
              </p>

              <div style={{ fontSize: "28px", color: "#ff4d4d", fontWeight: "bold", marginBottom: "30px" }}>
                ٤٥٠ جنيه
              </div>

              {/* Size Selection */}
              <div style={{ marginBottom: "20px" }}>
                <h3 style={{ marginBottom: "10px" }}>المقاس:</h3>
                <div style={{ display: "flex", gap: "10px" }}>
                  {["S", "M", "L", "XL", "XXL"].map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      style={{
                        padding: "8px 16px",
                        border: `2px solid ${selectedSize === size ? "#ff4d4d" : isDarkMode ? "#333" : "#ddd"}`,
                        background: selectedSize === size ? "#ff4d4d" : "transparent",
                        color: selectedSize === size ? "#fff" : isDarkMode ? "#fff" : "#000",
                        borderRadius: "6px",
                        cursor: "pointer",
                        transition: "0.3s",
                      }}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity */}
              <div style={{ marginBottom: "30px" }}>
                <h3 style={{ marginBottom: "10px" }}>الكمية:</h3>
                <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    style={{
                      padding: "8px 12px",
                      border: `1px solid ${isDarkMode ? "#333" : "#ddd"}`,
                      background: isDarkMode ? "#111" : "#f5f5f5",
                      color: isDarkMode ? "#fff" : "#000",
                      borderRadius: "4px",
                      cursor: "pointer",
                    }}
                  >
                    -
                  </button>
                  <span style={{ padding: "8px 16px", fontSize: "18px" }}>{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    style={{
                      padding: "8px 12px",
                      border: `1px solid ${isDarkMode ? "#333" : "#ddd"}`,
                      background: isDarkMode ? "#111" : "#f5f5f5",
                      color: isDarkMode ? "#fff" : "#000",
                      borderRadius: "4px",
                      cursor: "pointer",
                    }}
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Add to Cart Button */}
              <button
                style={{
                  width: "100%",
                  padding: "15px",
                  background: "#ff4d4d",
                  color: "#fff",
                  border: "none",
                  borderRadius: "8px",
                  fontSize: "18px",
                  fontWeight: "bold",
                  cursor: "pointer",
                  transition: "0.3s",
                  marginBottom: "15px",
                }}
                onMouseOver={(e) => (e.target.style.background = "#e63946")}
                onMouseOut={(e) => (e.target.style.background = "#ff4d4d")}
              >
                إضافة للسلة - {450 * quantity} جنيه
              </button>

              <button
                style={{
                  width: "100%",
                  padding: "15px",
                  background: "transparent",
                  color: "#ff4d4d",
                  border: "2px solid #ff4d4d",
                  borderRadius: "8px",
                  fontSize: "18px",
                  fontWeight: "bold",
                  cursor: "pointer",
                  transition: "0.3s",
                }}
                onMouseOver={(e) => {
                  e.target.style.background = "#ff4d4d"
                  e.target.style.color = "#fff"
                }}
                onMouseOut={(e) => {
                  e.target.style.background = "transparent"
                  e.target.style.color = "#ff4d4d"
                }}
              >
                شراء الآن
              </button>
            </div>
          </div>
        </div>

        <style jsx>{`
          @import url('https://fonts.googleapis.com/css2?family=Metal+Mania&display=swap');
          
          @media (max-width: 768px) {
            div[style*="grid-template-columns: 1fr 1fr"] {
              grid-template-columns: 1fr !important;
              gap: 20px !important;
            }
          }
        `}</style>
      </div>
    </div>
  )
}
