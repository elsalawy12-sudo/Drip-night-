import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import Link from "next/link"

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-primary font-space-grotesk">
              Drip Night
            </Link>
            <div className="hidden md:flex items-center gap-6">
              <Link href="/shop" className="text-foreground hover:text-primary transition-colors">
                المتجر
              </Link>
              <Link href="/lookbook" className="text-foreground hover:text-primary transition-colors">
                معرض الأزياء
              </Link>
              <Link href="/about" className="text-foreground hover:text-primary transition-colors">
                من نحن
              </Link>
              <Link href="/contact" className="text-primary font-semibold">
                تواصل معنا
              </Link>
              <Link href="/gallery" className="text-foreground hover:text-primary transition-colors">
                المعرض
              </Link>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/login">
                <Button variant="outline" size="sm">
                  تسجيل الدخول
                </Button>
              </Link>
              <Link href="/register">
                <Button size="sm">إنشاء حساب</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-12 px-4">
        <div className="container mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6 font-space-grotesk">
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">تواصل معنا</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            نحن هنا للإجابة على جميع استفساراتكم ومساعدتكم
          </p>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="hover:shadow-xl transition-all duration-300">
              <CardContent className="p-8">
                <h2 className="text-2xl font-bold text-card-foreground mb-6 font-space-grotesk">أرسل لنا رسالة</h2>
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-card-foreground mb-2">الاسم الأول</label>
                      <Input placeholder="أدخل اسمك الأول" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-card-foreground mb-2">الاسم الأخير</label>
                      <Input placeholder="أدخل اسمك الأخير" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">البريد الإلكتروني</label>
                    <Input type="email" placeholder="أدخل بريدك الإلكتروني" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">رقم الهاتف</label>
                    <Input type="tel" placeholder="أدخل رقم هاتفك" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">الموضوع</label>
                    <Input placeholder="موضوع الرسالة" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-card-foreground mb-2">الرسالة</label>
                    <Textarea placeholder="اكتب رسالتك هنا..." rows={5} />
                  </div>
                  <Button size="lg" className="w-full">
                    إرسال الرسالة
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <div className="space-y-8">
              <Card className="hover:shadow-xl transition-all duration-300">
                <CardContent className="p-8">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-xl text-primary-foreground">📍</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-card-foreground mb-2">العنوان</h3>
                      <p className="text-muted-foreground">الرياض، المملكة العربية السعودية</p>
                      <p className="text-muted-foreground">حي الملز، شارع الأمير محمد بن عبدالعزيز</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-xl transition-all duration-300">
                <CardContent className="p-8">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-xl text-accent-foreground">📞</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-card-foreground mb-2">الهاتف</h3>
                      <p className="text-muted-foreground">+966 50 123 4567</p>
                      <p className="text-muted-foreground">متاح من 9 صباحاً حتى 9 مساءً</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-xl transition-all duration-300">
                <CardContent className="p-8">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-chart-2 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-xl text-white">✉️</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-card-foreground mb-2">البريد الإلكتروني</h3>
                      <p className="text-muted-foreground">info@dripnight.com</p>
                      <p className="text-muted-foreground">support@dripnight.com</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-xl transition-all duration-300">
                <CardContent className="p-8">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-chart-3 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-xl text-white">🕒</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-card-foreground mb-2">ساعات العمل</h3>
                      <p className="text-muted-foreground">السبت - الخميس: 9:00 ص - 9:00 م</p>
                      <p className="text-muted-foreground">الجمعة: 2:00 م - 9:00 م</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 bg-card">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-card-foreground mb-4 font-space-grotesk">الأسئلة الشائعة</h2>
            <p className="text-muted-foreground text-lg">إجابات على أكثر الأسئلة شيوعاً</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-card-foreground mb-3">كم تستغرق عملية الشحن؟</h3>
                <p className="text-muted-foreground">
                  عادة ما تستغرق عملية الشحن من 2-5 أيام عمل داخل المملكة العربية السعودية.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-card-foreground mb-3">هل يمكنني إرجاع المنتج؟</h3>
                <p className="text-muted-foreground">
                  نعم، يمكنك إرجاع المنتج خلال 14 يوم من تاريخ الاستلام بشرط أن يكون في حالته الأصلية.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-card-foreground mb-3">ما هي طرق الدفع المتاحة؟</h3>
                <p className="text-muted-foreground">نقبل الدفع عند الاستلام، البطاقات الائتمانية، وتحويل بنكي.</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-card-foreground mb-3">كيف أعرف المقاس المناسب؟</h3>
                <p className="text-muted-foreground">
                  يمكنك الاطلاع على جدول المقاسات في صفحة كل منتج أو التواصل معنا للمساعدة.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-background border-t border-border py-12 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold text-foreground mb-4 font-space-grotesk">Drip Night</h3>
              <p className="text-muted-foreground">متجرك المفضل للملابس الشبابية العصرية</p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">روابط سريعة</h4>
              <div className="space-y-2">
                <Link href="/shop" className="block text-muted-foreground hover:text-primary transition-colors">
                  المتجر
                </Link>
                <Link href="/about" className="block text-muted-foreground hover:text-primary transition-colors">
                  من نحن
                </Link>
                <Link href="/contact" className="block text-muted-foreground hover:text-primary transition-colors">
                  تواصل معنا
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">خدمة العملاء</h4>
              <div className="space-y-2">
                <Link href="/shipping" className="block text-muted-foreground hover:text-primary transition-colors">
                  الشحن والتوصيل
                </Link>
                <Link href="/returns" className="block text-muted-foreground hover:text-primary transition-colors">
                  الإرجاع والاستبدال
                </Link>
                <Link href="/faq" className="block text-muted-foreground hover:text-primary transition-colors">
                  الأسئلة الشائعة
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4">تابعنا</h4>
              <div className="flex gap-4">
                <Button variant="outline" size="sm">
                  Instagram
                </Button>
                <Button variant="outline" size="sm">
                  TikTok
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center">
            <p className="text-muted-foreground">© 2025 Drip Night. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
