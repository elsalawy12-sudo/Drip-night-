"use client"

interface ThemeToggleProps {
  isDarkMode: boolean
  onToggle: () => void
}

export default function ThemeToggle({ isDarkMode, onToggle }: ThemeToggleProps) {
  return (
    <div
      onClick={onToggle}
      style={{
        position: "fixed",
        top: "20px",
        right: "20px",
        zIndex: 10000,
        width: "60px",
        height: "30px",
        background: isDarkMode ? "#333" : "#ddd",
        borderRadius: "15px",
        cursor: "pointer",
        transition: "all 0.3s ease",
        display: "flex",
        alignItems: "center",
        padding: "3px",
        border: `2px solid ${isDarkMode ? "#555" : "#bbb"}`,
      }}
    >
      <div
        style={{
          width: "24px",
          height: "24px",
          background: isDarkMode ? "#666" : "#fff",
          borderRadius: "50%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "12px",
          transform: isDarkMode ? "translateX(0px)" : "translateX(26px)",
          transition: "transform 0.3s ease",
          boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
        }}
      >
        {isDarkMode ? "🌙" : "☀️"}
      </div>
    </div>
  )
}
